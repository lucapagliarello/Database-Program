create TABLE if NOT exists IMPIEGATO(
ID INTEGER PRIMARY KEY, 
nome VARCHAR(20), 
cognome VARCHAR(20), 
anno INTEGER, 
indirizzo VARCHAR(50),
citta VARCHAR(20)
);

create table if not exists AZIENDA(
nome varchar(20) PRIMARY KEY,
citta varchar(30)
);


create TABLE if NOT exists LAVORA(
id_impiegato integer,
azienda varchar(20),
salario integer,
INDEX new_id(id_impiegato),
INDEX new_azienda(azienda),
FOREIGN KEY(id_impiegato) REFERENCES IMPIEGATO(ID) on update cascade,
FOREIGN KEY(azienda) REFERENCES AZIENDA(nome) on update cascade,
PRIMARY KEY(id_impiegato,azienda)
);

create TABLE if NOT exists CAPI(
id_impiegato INTEGER PRIMARY KEY,
id_capo INTEGER,
INDEX new_capo(id_capo),
INDEX new_impiegato(id_impiegato),
FOREIGN KEY (id_impiegato) REFERENCES IMPIEGATO(ID) on update cascade, 
FOREIGN KEY (id_capo) REFERENCES IMPIEGATO(ID) on update cascade
);
/*
-- 2
DELIMITER //
CREATE PROCEDURE if NOT EXISTS op2(IN azienda VARCHAR(255))
BEGIN
	DROP TEMPORARY TABLE if EXISTS temp;
	CREATE TEMPORARY TABLE temp (
		nome VARCHAR(255),
		cognome VARCHAR(255),
		citta VARCHAR(255)
	);
	
	INSERT INTO temp
	SELECT i.nome, i.cognome, i.citta
	FROM impiegato i
	JOIN lavora l ON i.ID = l.id_impiegato
	WHERE l.azienda = azienda;
END //
delimiter ;
CALL op2('MORGAN STANLEY');
SELECT * FROM temp;*/
/*
-- 3
delimiter //
CREATE PROCEDURE if NOT EXISTS op3(IN azienda VARCHAR(255), IN guadagno INTEGER)
BEGIN
	DROP TEMPORARY TABLE if EXISTS temp;
	CREATE TEMPORARY TABLE temp(
		nome VARCHAR(255),
		indirizzo VARCHAR(255),
		citta VARCHAR(255)
	);
	
	INSERT INTO temp
	SELECT i.nome, i.indirizzo, i.citta
	FROM impiegato i
	JOIN lavora l ON i.ID = l.id_impiegato
	WHERE l.azienda = azienda AND l.salario > guadagno;
END //
delimiter ;
CALL op3('FIAT', 10000);
SELECT * FROM temp; */
/*
-- 4
SELECT *
FROM IMPIEGATO
WHERE ID NOT IN (SELECT ID_IMPIEGATO FROM LAVORA WHERE AZIENDA='TELECOM'); */
/*
-- 5
delimiter //
CREATE PROCEDURE if NOT EXISTS op5(IN azienda VARCHAR(255), IN lettera CHAR(1))
BEGIN
	SELECT * 
	FROM azienda
	WHERE citta IN (SELECT citta
						 FROM azienda
						 WHERE nome = azienda)
	AND nome NOT LIKE CONCAT(lettera, '%') AND nome <> azienda;
END //
delimiter ;
CALL op5('ACCENTURE', 'G'); */

-- 6

/*
-- 7
CREATE VIEW if NOT EXISTS op7 AS
SELECT i.*
FROM impiegato i
JOIN lavora l ON i.ID = l.id_impiegato
WHERE l.azienda LIKE 'F%'
		AND l.salario < 10000
		AND i.ID IN (SELECT c.id_impiegato
						 FROM capi c
						 JOIN impiegato i1 ON c.id_capo = i1.ID
						 WHERE i1.anno <= 1960); */
/*						 
-- 8
delimiter //
CREATE TRIGGER op8
AFTER INSERT ON lavora
FOR EACH ROW
BEGIN
	if EXISTS (SELECT * FROM impiegato WHERE ID = NEW.id_impiegato)
	then
		INSERT INTO capi
		SELECT NEW.id_impiegato, c.id_capo
		FROM impiegato i
		JOIN capi c ON i.ID = c.id_capo
		WHERE i.citta IN (SELECT citta
								FROM impiegato i
								WHERE i.ID = NEW.id_impiegato)
		GROUP BY c.id_capo
		HAVING COUNT(*) <= ALL(SELECT COUNT(*)
									  FROM capi c1
									  JOIN impiegato i1 ON i1.ID = c1.id_capo
									  WHERE i1.citta IN (SELECT citta
									  							FROM impiegato i
									  							WHERE i.ID = NEW.id_impiegato)
									  GROUP BY c1.id_capo)
		LIMIT 1;
	END if;						  
END // */
/* 
-- 9
SELECT *
FROM impiegato i
WHERE EXISTS (SELECT *
				  FROM impiegato i1
				  JOIN capi c ON i1.ID = c.id_capo
				  WHERE i1.nome = i.nome
				  AND i1.cognome = i.cognome
				  AND i1.anno = i.anno
				  AND c.id_impiegato = I.ID); */
/*	  
-- 10
delimiter //
CREATE TRIGGER op10
AFTER INSERT ON lavora
FOR EACH ROW
BEGIN
	if EXISTS (SELECT COUNT(*) AS numero_aziende
				  FROM lavora l
				  JOIN impiegato i ON l.id_impiegato = i.ID
				  WHERE l.id_impiegato = NEW.id_impiegato
				  HAVING numero_aziende >= 3)
	then
		CREATE TABLE if NOT EXISTS lavoratori_mobili (
			ID INTEGER PRIMARY KEY,
			Nome VARCHAR(255),
			Cognome VARCHAR(255),
			Num_aziende INTEGER
		);
	END if;
	
	if EXISTS (SELECT * FROM lavoratori_mobili WHERE ID = NEW.id_impiegato)
	then
		UPDATE lavoratori_mobili
		SET Num_aziende = Num_aziende + 1
		WHERE ID = NEW.id_impiegato
	ELSE
		INSERT INTO lavoratori_mobili
		SELECT ID, Nome, Cognome, 3
		FROM impiegato
		WHERE ID = NEW.id_impiegato;
	END if;
END // */

-- 11
SELECT(COUNT(ALL id_impiegato)/COUNT(*)*100) AS Rapporto_di_occupazione
FROM impiegato i
LEFT JOIN lavora l ON i.ID = l.id_impiegato