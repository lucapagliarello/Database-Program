/*
CREATE TABLE IF NOT EXISTS IMPIEGATO (
    ID INTEGER PRIMARY KEY,
    nome VARCHAR(255),
    cognome VARCHAR(255),
    annoNascita INTEGER,
    indirizzo VARCHAR(255),
    città VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS AZIENDA (
    Nome VARCHAR(255) PRIMARY KEY,
    città VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS LAVORA (
    id_impiegato INTEGER,
    azienda VARCHAR(255),
    salarioAnnuo INTEGER,
    FOREIGN KEY (id_impiegato) REFERENCES IMPIEGATO(ID),
    FOREIGN KEY (azienda) REFERENCES AZIENDA(Nome)
);

CREATE TABLE IF NOT EXISTS CAPI (
    id_impiegato INTEGER,
    id_capo INTEGER,
    FOREIGN KEY (id_impiegato) REFERENCES IMPIEGATO(ID),
    FOREIGN KEY (id_capo) REFERENCES IMPIEGATO(ID)
);


-- 2
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS op1(IN nome_azienda VARCHAR(255))
BEGIN
   
    DROP TEMPORARY TABLE IF EXISTS temp;
    CREATE TEMPORARY TABLE temp (
        nome VARCHAR(255),
        cognome VARCHAR(255),
        citta VARCHAR(255)
    );

    INSERT INTO temp
    SELECT i.nome, i.cognome, i.città
    FROM IMPIEGATO i
    JOIN LAVORA l ON i.ID = l.id_impiegato
    WHERE l.azienda = nome_azienda;
END //
DELIMITER ;
CALL op1('MORGAN STANLEY');
SELECT * FROM temp;

-- 3
DELIMITER //

CREATE PROCEDURE IF NOT EXISTS op2(IN nome_azienda VARCHAR(255), salario_minimo INTEGER)
BEGIN
    
    DROP TEMPORARY TABLE IF EXISTS temp;
    CREATE TEMPORARY TABLE temp (
        nome VARCHAR(255),
        indirizzo VARCHAR(255),
        citta VARCHAR(255)
    );

    INSERT INTO temp
    SELECT i.nome, i.indirizzo, i.citta
    FROM IMPIEGATO i
    JOIN LAVORA l ON i.ID = l.id_impiegato
    WHERE l.azienda = nome_azienda
      AND l.salarioAnnuo > salario_minimo;
END //

DELIMITER ;
CALL op2('FIAT', 10000);
SELECT * FROM temp;

-- 4
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS op3(IN nome_azienda VARCHAR(255))
BEGIN
    DROP TEMPORARY TABLE IF EXISTS temp;
    CREATE TEMPORARY TABLE temp (
        nome VARCHAR(255),
        cognome VARCHAR(255),
        indirizzo VARCHAR(255),
        città VARCHAR(255)
    );

    INSERT INTO temp
    SELECT i.nome, i.cognome, i.indirizzo, i.citta
    FROM IMPIEGATO i
    EXCEPT
    SELECT i.nome, i.cognome, i.indirizzo, i.citta
    FROM IMPIEGATO i
    JOIN LAVORA l ON i.ID = l.id_impiegato
    WHERE l.azienda = nome_azienda;
END //

DELIMITER ;
CALL op3('TELECOM');
SELECT * FROM temp;


-- 5
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS op4(IN nome_azienda VARCHAR(255), IN lettera CHAR(1))
BEGIN
    
    DROP TEMPORARY TABLE IF EXISTS temp;
    CREATE TEMPORARY TABLE temp (
        nome VARCHAR(255),
        citta VARCHAR(255)
    );
    
    INSERT INTO temp
    SELECT A2.nome, A2.città
    FROM azienda A1
    JOIN azienda A2 ON A1.città = A2.città
    WHERE A1.Nome = nome_azienda
    AND A2.Nome NOT LIKE CONCAT(lettera, '%');
    
END //

DELIMITER ;
CALL op4('ACCENTURE', 'G');
SELECT * FROM temp;

-- 6
CREATE VIEW IF NOT EXISTS op7 AS
	SELECT 
    	c.id_capo,
    	i.nome AS nome_capo,
    	i.cognome AS cognome_capo,
    	l.salarioAnnuo,
    	COUNT(c.id_impiegato) AS numero_dipendenti
	FROM CAPI c
	JOIN IMPIEGATO i ON c.id_capo = i.ID
	JOIN LAVORA l ON c.id_capo = l.id_impiegato
	GROUP BY c.id_capo;
    
-- 7
CREATE VIEW IF NOT EXISTS op8 AS
	SELECT i.ID, i.nome, i.cognome, i.annoNascita, i.indirizzo, i.città, l.azienda, l.salarioAnnuo
	FROM IMPIEGATO i
	JOIN LAVORA l ON i.ID = l.id_impiegato
	JOIN CAPI c ON i.ID = c.id_impiegato
	JOIN AZIENDA a ON l.azienda = a.Nome
	WHERE a.Nome LIKE 'F%'      
   AND l.salarioAnnuo < 60000           
   AND (SELECT i2.annoNascita            
      	FROM IMPIEGATO i2
         WHERE i2.ID = c.id_capo) < 1960;
*/
-- 8
delimiter //
CREATE TRIGGER op9
AFTER INSERT ON impiegato
FOR EACH ROW
BEGIN
	if EXISTS(SELECT * FROM impiegato WHERE id = NEW.id)
	then
	UPDATE impiegato
	
END //

