CREATE TABLE if NOT EXISTS PERSONA(
	cf VARCHAR(255) PRIMARY KEY,
	nome VARCHAR(255),
	cognome VARCHAR(255),
	data_nascita DATE,
	indirizzo VARCHAR(255),
	n_vaccini INTEGER
);

CREATE TABLE if NOT EXISTS MALATTIA(
	codice INTEGER PRIMARY KEY,
	nome VARCHAR(255),
	tipo VARCHAR(255),
	persone_contagiate INTEGER
);

CREATE TABLE if NOT EXISTS VACCINO(
	codice INTEGER PRIMARY KEY,
	rischio INTEGER,
	importanza INTEGER,
	anno_introduzione YEAR,
	malattia_prevenuta INTEGER,
	FOREIGN KEY (malattia_prevenuta) REFERENCES MALATTIA(codice)
);

CREATE TABLE if NOT EXISTS VACCINAZIONE(
	persona VARCHAR(255),
	vaccino INTEGER,
	data_vaccinazione DATE,
	PRIMARY KEY(persona, vaccino),
	FOREIGN KEY(persona) REFERENCES PERSONA(cf),
	FOREIGN KEY(vaccino) REFERENCES VACCINO(codice)
);

CREATE TABLE if NOT EXISTS CONTAGIO(
	persona VARCHAR(255),
	malattia INTEGER,
	data_diagnosi DATE,
	PRIMARY KEY(persona, malattia),
	FOREIGN KEY(persona) REFERENCES PERSONA(cf),
	FOREIGN KEY(malattia) REFERENCES MALATTIA(codice)
);

delimiter //
CREATE PROCEDURE if NOT EXISTS op2(IN tre_cifre CHAR(3))
	BEGIN
		SELECT *
		FROM persona
		WHERE cf LIKE CONCAT(tre_cifre,'%');		
	END //
	
delimiter ;
CALL op2('clb'); -- si puo fare anche senza tabella temporanea

delimiter //
CREATE PROCEDURE if NOT EXISTS op3(IN anno YEAR)
	BEGIN
		SELECT *
		FROM vaccino v
		WHERE v.anno_introduzione = anno;
	END //
delimiter ;

delimiter //
CREATE PROCEDURE if NOT EXISTS op4(IN malattia INTEGER)
	BEGIN 
		SELECT *
		FROM persona p
		JOIN contagio c ON p.cf = c.persona
		WHERE c.malattia = malattia;
	END //
delimiter ;

DROP PROCEDURE if EXISTS op5;
delimiter //
CREATE PROCEDURE if NOT EXISTS op5(IN anno YEAR)
	BEGIN 
		-- serve per il punto 7
		DROP TEMPORARY TABLE if EXISTS anni_vaccini;
		CREATE TEMPORARY TABLE if NOT EXISTS anni_vaccini(
			numero INTEGER,
			anno YEAR
		);
		
		INSERT INTO anni_vaccini
		SELECT COUNT(*) AS num_vaccini, v.anno_introduzione
		FROM vaccino v
		WHERE v.anno_introduzione >= anno
		GROUP BY anno_introduzione;
	END //
delimiter ;
CALL op5('1994');
SELECT * FROM anni_vaccini;

-- 6
CREATE VIEW if NOT EXISTS num_persone AS
	SELECT COUNT(*) AS Num_Vaccinazioni, YEAR(data_vaccinazione) AS Anno
	FROM vaccinazione
	GROUP BY anno;
	
SELECT AVG(Num_Vaccinazioni) AS Numero_Medio_Annuo FROM num_persone;

-- 7
delimiter //
DROP PROCEDURE if EXISTS op7;
CREATE PROCEDURE if NOT EXISTS op7 (IN anno_input YEAR)
	BEGIN
		DROP TEMPORARY TABLE if EXISTS temp;
		CREATE TEMPORARY TABLE if not EXISTS temp(
			num_vaccini INTEGER,
			anno YEAR
		);
		
		CALL op5(anno_input);
		
		while anno_input <= YEAR(CURRENT_DATE()) DO
			if anno_input IN (SELECT anno FROM anni_vaccini) then
				INSERT INTO temp
				SELECT numero, anno 
				FROM anni_vaccini 
				WHERE anno = anno_input;
			ELSE
				INSERT INTO temp VALUES (0, anno_input);
			END if;
			SET anno_input = anno_input + 1;
		END while;		
	END //
delimiter ;

CALL op7(1994);
SELECT * FROM temp;

-- alternativa
delimiter //
DROP PROCEDURE if EXISTS op7_2;
CREATE PROCEDURE if NOT EXISTS op7_2 (IN anno_input YEAR)
	BEGIN
		CALL op5(anno_input);
		
		DROP TEMPORARY TABLE if EXISTS anni;
		CREATE TEMPORARY TABLE if not exists anni(
			anno YEAR
		);
		
		while anno_input <= YEAR(CURRENT_DATE()) DO
			INSERT INTO anni VALUES (anno_input);
			SET anno_input = anno_input + 1;
		END while;
		
		SELECT COUNT(ALL anni_vaccini.numero), anni.anno
		FROM anni
		LEFT JOIN anni_vaccini ON anni.anno = anni_vaccini.anno
		GROUP BY anni.anno;
	END //
delimiter ;
CALL op7_2(1994);
	
CREATE VIEW if NOT EXISTS op8 AS
	SELECT cf
	FROM persona
	WHERE cf NOT IN (
						SELECT v.persona
						FROM vaccinazione v
						JOIN vaccino va ON v.vaccino = va.codice
						WHERE va.importanza = (SELECT MAX(importanza) FROM vaccino)
							);
							
SELECT * FROM op8;

CREATE VIEW if NOT EXISTS op9 AS
	SELECT c.persona AS Persona, 
			 va.malattia_prevenuta AS malattia, 
			 v.vaccino AS vaccino, 
			 v.data_vaccinazione AS Data_vaccinazione, 
			 c.data_diagnosi AS Data_contagio
	FROM contagio c
	JOIN vaccinazione v ON c.persona = v.persona
	JOIN vaccino va ON va.codice = v.vaccino AND va.malattia_prevenuta = c.malattia;
	
	
-- 10
SELECT(AVG(Data_vaccinazione) - AVG(Data_contagio)) AS Tempo_medio FROM op9;

delimiter //
CREATE TRIGGER if NOT EXISTS op11
AFTER INSERT ON vaccinazione
FOR EACH ROW 
	BEGIN
		if EXISTS(SELECT * FROM persona WHERE cf = NEW.persona)
		then
			UPDATE persona
			SET N_vaccini = N_vaccini + 1
			WHERE cf = NEW.persona;
		END if;
	END //
delimiter ;
-- per vedere se è corretto bisogna effettuare un inserimento per scatenare il trigger


delimiter //
CREATE TRIGGER if NOT EXISTS op11_2
AFTER INSERT ON contagio
FOR EACH ROW
	BEGIN
		if EXISTS(SELECT * FROM malattia WHERE codice = NEW.malattia)
		then
			UPDATE malattia
			SET Persone_contagiate = Persone_contagiate + 1
			WHERE codice = NEW.malattia;
		END if;
	END //