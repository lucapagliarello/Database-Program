CREATE DATABASE if NOT EXISTS esercitazione_2_12;
USE esercitazione_2_12;

CREATE TABLE if NOT EXISTS pilota (
	CF VARCHAR(255) PRIMARY KEY,
	Nome VARCHAR(255),
	Cognome VARCHAR(255),
	DataNascita DATE,
	Indirizzo VARCHAR(255),
	N_Gare INTEGER
);

CREATE TABLE if NOT EXISTS campionato (
	Codice INTEGER PRIMARY KEY,
	Nome VARCHAR(255),
	Tipo VARCHAR(255),
	PilotiVincitori INTEGER
);

CREATE TABLE if NOT EXISTS gara (
	Codice INTEGER PRIMARY KEY,
	Difficolta INTEGER,
	Coefficiente INTEGER,
	annoIntroduzione INTEGER,
	CampionatoAppartenenza INTEGER,
	FOREIGN KEY (CampionatoAppartenenza) REFERENCES campionato(Codice)
);

CREATE TABLE if NOT EXISTS vittorie (
	Pilota VARCHAR(255),
	Gara INTEGER,
	DataVittoria DATE,
	PRIMARY KEY(Pilota, Gara, DataVittoria),
	FOREIGN KEY (Pilota) REFERENCES pilota(CF),
	FOREIGN KEY (Gara) REFERENCES campionato(Codice)
);

CREATE TABLE if NOT EXISTS albo (
	Pilota VARCHAR(255),
	Campionato INTEGER,
	Anno INTEGER,
	PRIMARY KEY(Campionato, Anno),
	FOREIGN KEY (Pilota) REFERENCES pilota(CF),
	FOREIGN KEY (Campionato) REFERENCES campionato(Codice)
);

-- 2
DROP PROCEDURE if EXISTS op2;
delimiter //
CREATE PROCEDURE if NOT EXISTS op2(IN anno YEAR)
BEGIN
	SELECT p.CF, p.Nome, p.Cognome
	FROM pilota p
	JOIN vittorie v ON p.CF = v.Pilota
	WHERE YEAR(v.DataVittoria) = anno;
END //
delimiter ;
CALL op2(2012);

-- 3
DROP PROCEDURE if EXISTS op3;
delimiter //
CREATE PROCEDURE if NOT EXISTS op3(IN anno YEAR)
BEGIN
	SELECT p.CF, p.Nome, p.Cognome
	FROM pilota p
	WHERE p.CF NOT IN (SELECT v.pilota
							 FROM vittorie v
							 WHERE YEAR(v.DataVittoria) = anno);
END //
delimiter ;
CALL op3(2012);

-- 4
DROP PROCEDURE if EXISTS op4;
delimiter //
CREATE PROCEDURE if NOT EXISTS op4(IN nome VARCHAR(255), IN cognome VARCHAR(255))
BEGIN
	SELECT *
	FROM campionato c
	JOIN albo a ON c.Codice = a.Pilota
	JOIN pilota p ON a.Pilota = p.CF
	WHERE p.Nome = nome AND p.Cognome = cognome;
END //
delimiter ;
CALL op4('Davide', 'Mangoni');

-- 5
delimiter //
CREATE PROCEDURE if NOT EXISTS op5()
BEGIN
	SELECT p.CF, p.Nome, p.Cognome
	FROM pilota p
	JOIN vittorie v ON p.CF = v.Pilota
	JOIN gara g ON v.Gara = g.Codice WHERE year(v.DataVittoria) = g.annoIntroduzione;
END //
delimiter ;
CALL op5;

-- 6
DROP PROCEDURE if EXISTS op6;
delimiter //
CREATE PROCEDURE if NOT EXISTS op6(IN livello INTEGER)
BEGIN
	SELECT V.pilota , COUNT(*) AS num_gare
	FROM vittorie v 
	JOIN gara g ON v.Gara=g.Codice
	WHERE g.Difficolta = livello
	GROUP BY V.pilota
	HAVING num_gare >= ALL (SELECT COUNT(*)
								FROM vittorie V 
								JOIN gara G ON V.Gara = G.Codice
								WHERE G.Difficolta = livello
								GROUP BY V.pilota);
END //
delimiter ;
CALL op6(2);

-- 7

CREATE VIEW if NOT EXISTS vittoriePerAnno AS
	SELECT v.Pilota AS CF_PILOTA, g.CampionatoAppartenenza AS CODICE_CAMPIONATO, YEAR(v.dataVittoria) AS Anno, COUNT(*) AS Num_Vittorie
	FROM vittorie v
	JOIN gara g ON v.Gara = g.Codice
	GROUP BY v.Pilota, g.CampionatoAppartenenza, YEAR(v.dataVittoria);

DROP PROCEDURE if EXISTS op7;
delimiter //
CREATE PROCEDURE if NOT EXISTS op7(IN cf CHAR(16))
BEGIN
	SELECT vi.CF_PILOTA, vi.Anno, AVG(vi.Num_Vittorie) AS Num_Medio_Vittorie
	FROM vittorieperanno vi
	WHERE vi.CF_PILOTA = cf
	GROUP BY vi.Anno;
END //
delimiter ;
CALL op7('LOLRTI75F82R642T'); -- DA CAPIRE PERCHE' NON MI DA RISULTATI DALLA SOLUZIONE

-- 8
CREATE VIEW if NOT EXISTS op8 AS
	SELECT p.CF, p.Nome, p.Cognome
	FROM pilota p
	JOIN vittorie v ON p.CF = v.Pilota
	WHERE NOT EXISTS
	(
		SELECT *
		FROM vittorie v
		JOIN gara g ON v.Gara = g.Codice
		WHERE g.Coefficiente > (SELECT MIN(coefficiente) FROM gara)
		AND v.Pilota = p.CF
	);
SELECT * FROM op8;

-- 9
delimiter //
CREATE TRIGGER if NOT EXISTS op9
AFTER INSERT ON vittorie
FOR EACH ROW 
BEGIN
	if EXISTS (SELECT * FROM pilota p WHERE p.CF = NEW.pilota) then
		UPDATE pilota
		SET n_gare = n_gare + 1
		WHERE p.CF = NEW.pilota;
	END if;
	
	if EXISTS (SELECT * FROM campionato c WHERE Codice IN (SELECT CampionatoAppartenenza
																		  FROM gara
																		  WHERE Codice = NEW.Gara)) then
		UPDATE campionato
		SET pilotivincitori = (SELECT COUNT(DISTINCT pilota)
									   FROM vittorie 
									   WHERE gara = NEW.gara)
		WHERE Codice IN (SELECT CampionatoAppartenenza
								FROM gara
								WHERE Codice = NEW.Gara);
	END if;
END //

-- 10
DROP PROCEDURE if EXISTS vincitore_campionato;
delimiter //
CREATE PROCEDURE if NOT EXISTS vincitore_campionato(IN anno INTEGER, IN camp INTEGER)
BEGIN
	DROP TEMPORARY TABLE if EXISTS tmp;
	CREATE TEMPORARY TABLE if NOT EXISTS tmp(
		cf CHAR(16),
		num_gare INTEGER
	);
	
	INSERT INTO tmp
	SELECT v.Pilota, COUNT(*) AS gare_vinte
	FROM vittorie v
	JOIN gara g ON v.Gara = g.Codice
	WHERE g.CampionatoAppartenenza = camp AND YEAR(v.DataVittoria) = anno
	GROUP BY v.Pilota
	HAVING gare_vinte >= ALL(SELECT COUNT(*) -- il confronto di count con tutti i valori contenuti nella tabella di qua
									 FROM vittorie v
									 JOIN gara g ON v.Gara = g.Codice
									 WHERE g.CampionatoAppartenenza = camp AND YEAR(v.DataVittoria) = anno
									 GROUP BY v.Pilota)
	LIMIT 1; -- sbagliato ma a causa di un problema del testo è possibile che vi siano piu vincitori
END //
-- l'order by limit 1 non deve essere fatto per considerare il maggiore numero di gare in quanto mi va a prendere solo il primo valore


CREATE TRIGGER if NOT EXISTS op10
AFTER INSERT ON vittorie
FOR EACH ROW
BEGIN
SET @camp = (SELECT CampionatoAppartenenza
				  		FROM gara 
						WHERE Codice = NEW.Gara);
						
CALL vincitore_campionato(YEAR(NEW.dataVittoria), @camp);																			  

	if EXISTS(SELECT * FROM albo WHERE anno = YEAR(NEW.dataVittoria) AND campionato = @camp) then
		UPDATE albo
		SET pilota = SELECT cf FROM tmp
		WHERE anno = YEAR(NEW.dataVittoria) AND campionato = @camp;
	ELSE
		INSERT INTO albo VALUES(NEW.Pilota, @camp, YEAR(NEW.dataVittoria));
	END if;																										  
END //
