insert into PERSONA(CF, Nome, Cognome, DataNascita, Indirizzo, N_qualifiche) values('AAAAAA00X00ZZZZY', 'Antonio', 'Abate', '1979-05-14', 'Via Ancona, 1', 0);
insert into PERSONA(CF, Nome, Cognome, DataNascita, Indirizzo, N_qualifiche) values('BBBBBB00X00ZZZZY', 'Bruno', 'Bernardi', '1964-09-21', 'Via Biagi, 2', 0);
insert into PERSONA(CF, Nome, Cognome, DataNascita, Indirizzo, N_qualifiche) values('CCCCCC00X00ZZZZY', 'Carla', 'Comi', '1981-02-06', 'Via Cagliari, 3', 0);
insert into PERSONA(CF, Nome, Cognome, DataNascita, Indirizzo, N_qualifiche) values('DDDDDD00X00ZZZZY', 'Dario', 'Di Natale', '1975-05-06', 'Via Dante, 4', 0);
insert into PERSONA(CF, Nome, Cognome, DataNascita, Indirizzo, N_qualifiche) values('EEEEEE00X00ZZZZY', 'Enzo', 'Erri', '1985-07-30', 'Via Enna, 5', 0);
insert into PERSONA(CF, Nome, Cognome, DataNascita, Indirizzo, N_qualifiche) values('FFFFFF00X00ZZZZY', 'Francesco', 'Ferrante', '1988-12-08', 'Via Foggia, 6', 0);
insert into PERSONA(CF, Nome, Cognome, DataNascita, Indirizzo, N_qualifiche) values('GGGGGG00X00ZZZZY', 'Giorgia', 'Grandi', '1990-03-11', 'Via Genova, 6', 0);
insert into PERSONA(CF, Nome, Cognome, DataNascita, Indirizzo, N_qualifiche) values('HHHHHH00X00ZZZZY', 'Horace', 'Huxley', '1976-01-21', 'Via Heidelberg, 7', 0);
insert into PERSONA(CF, Nome, Cognome, DataNascita, Indirizzo, N_qualifiche) values('IIIIII00X00ZZZZY', 'Ilaria', 'Imbriani', '1986-09-15', 'Via Imola, 8', 0);
insert into PERSONA(CF, Nome, Cognome, DataNascita, Indirizzo, N_qualifiche) values('LLLLLL00X00ZZZZY', 'Luca', 'Leno', '1981-11-11', 'Via Luci, 9', 0);
insert into PERSONA(CF, Nome, Cognome, DataNascita, Indirizzo, N_qualifiche) values('MMMMMM00X00ZZZZY', 'Mario', 'Mirasi', '1980-02-25', 'Via Milano, 10', 0);

insert into COMPETENZA(Codice, Nome, Tipo) values(1, 'informatica', 'tecnica');
insert into COMPETENZA(Codice, Nome, Tipo) values(2, 'elettronica', 'tecnica');
insert into COMPETENZA(Codice, Nome, Tipo) values(3, 'contabile', 'amministrativa');
insert into COMPETENZA(Codice, Nome, Tipo) values(4, 'legale', 'amministrativa');
insert into COMPETENZA(Codice, Nome, Tipo) values(5, 'statistica', 'tecnica');
insert into COMPETENZA(Codice, Nome, Tipo) values(6, 'marketing', 'commerciale');
insert into COMPETENZA(Codice, Nome, Tipo) values(7, 'pubblicitaria', 'commerciale');

insert into QUALIFICA(Codice, Nome, Importanza, AnnoIntroduzione, CompetenzaAcquisita, N_Persone) values(1, 'software engineer', 10, 2001, 1, 0);
insert into QUALIFICA(Codice, Nome, Importanza, AnnoIntroduzione, CompetenzaAcquisita, N_Persone) values(2, 'web programmer', 9, 2001, 1, 0);
insert into QUALIFICA(Codice, Nome, Importanza, AnnoIntroduzione, CompetenzaAcquisita, N_Persone) values(3, 'circuit designer', 8, 1998, 2, 0);
insert into QUALIFICA(Codice, Nome, Importanza, AnnoIntroduzione, CompetenzaAcquisita, N_Persone) values(4, 'circuit tester', 7, 1998, 2, 0);
insert into QUALIFICA(Codice, Nome, Importanza, AnnoIntroduzione, CompetenzaAcquisita, N_Persone) values(5, 'commercialista', 6, 1993, 3, 0);
insert into QUALIFICA(Codice, Nome, Importanza, AnnoIntroduzione, CompetenzaAcquisita, N_Persone) values(6, 'assistente', 5, 1993, 3, 0);
insert into QUALIFICA(Codice, Nome, Importanza, AnnoIntroduzione, CompetenzaAcquisita, N_Persone) values(7, 'consulente', 4, 1993, 4, 0);
insert into QUALIFICA(Codice, Nome, Importanza, AnnoIntroduzione, CompetenzaAcquisita, N_Persone) values(8, 'data scientist', 8, 2002, 5, 0);
insert into QUALIFICA(Codice, Nome, Importanza, AnnoIntroduzione, CompetenzaAcquisita, N_Persone) values(9, 'grafico', 7, 1999, 7, 0);
insert into QUALIFICA(Codice, Nome, Importanza, AnnoIntroduzione, CompetenzaAcquisita, N_Persone) values(10, 'analista vendite', 6, 1998, 6, 0);


insert into ATTESTATO values ('AAAAAA00X00ZZZZY', 1, '2018-05-20');
insert into ATTESTATO values('AAAAAA00X00ZZZZY', 3, '2018-05-20');
insert into ATTESTATO values('AAAAAA00X00ZZZZY', 8, '2018-05-20');
insert into ATTESTATO values('BBBBBB00X00ZZZZY', 2, '2017-09-14');
insert into ATTESTATO values('CCCCCC00X00ZZZZY', 3, '2016-01-12');
insert into ATTESTATO values('DDDDDD00X00ZZZZY', 4, '2015-08-22');
insert into ATTESTATO values('EEEEEE00X00ZZZZY', 5, '2016-04-08');
insert into ATTESTATO values('FFFFFF00X00ZZZZY', 6, '2017-10-05');
insert into ATTESTATO values('GGGGGG00X00ZZZZY', 7, '2018-06-19');
insert into ATTESTATO values('HHHHHH00X00ZZZZY', 8, '2017-08-26');
insert into ATTESTATO values('IIIIII00X00ZZZZY', 1, '2016-12-01');
insert into ATTESTATO values('LLLLLL00X00ZZZZY', 9, '2017-06-21');
insert into ATTESTATO values('MMMMMM00X00ZZZZY', 10, '2018-01-10');

insert into USO values('AAAAAA00X00ZZZZY', 1, '2018-09-21');
insert into USO values('BBBBBB00X00ZZZZY', 2, '2018-02-19');
insert into USO values('DDDDDD00X00ZZZZY', 4, '2017-10-06');
insert into USO values('EEEEEE00X00ZZZZY', 5, '2016-11-04');
insert into USO values('GGGGGG00X00ZZZZY', 7, '2018-11-02');