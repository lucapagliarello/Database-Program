CREATE DATABASE if not exists esercitazione28_10;
USE esercitazione28_10;
-- 1
CREATE TABLE if not exists persona (
	CF VARCHAR(16) PRIMARY KEY,
	Nome VARCHAR(255),
	Cognome VARCHAR(255),
	DataNascita DATE,
	Indirizzo VARCHAR(255),
	N_qualifiche INTEGER
);

CREATE TABLE if not exists competenza (
	Codice INTEGER PRIMARY KEY,
	Nome VARCHAR(255), 
	Tipo VARCHAR(255)
);

CREATE TABLE if not exists qualifica (
	Codice INTEGER PRIMARY KEY,
	Nome VARCHAR(30),
	Importanza INTEGER, 
	AnnoIntroduzione INTEGER,
	CompetenzaAcquisita INTEGER,
	N_Persone INTEGER,
	FOREIGN KEY (CompetenzaAcquisita) REFERENCES COMPETENZA(Codice)
);

CREATE TABLE if not exists attestato (
	Persona VARCHAR(16),
	Qualifica INTEGER,
	Data DATE,
	FOREIGN KEY(Persona) REFERENCES PERSONA(CF),
	FOREIGN KEY(Qualifica) REFERENCES QUALIFICA(Codice),
	PRIMARY KEY(Persona,qualifica)
);


CREATE TABLE if not exists uso (
	Persona VARCHAR(16),
	Qualifica INTEGER,
	Data DATE,
	FOREIGN KEY(Persona) REFERENCES PERSONA(CF),
	FOREIGN KEY(Qualifica) REFERENCES QUALIFICA(Codice),
	PRIMARY KEY(Persona,Qualifica)
);
/*
-- 2
delimiter //
CREATE PROCEDURE if NOT EXISTS op2(IN trecifre CHAR(3))
BEGIN
	DROP TEMPORARY TABLE if EXISTS temp;
	CREATE TEMPORARY TABLE temp(
		CF VARCHAR(16),
		Nome VARCHAR(255),
		Cognome VARCHAR(255),
		DataNascita DATE,
		Indirizzo VARCHAR(255),
		N_qualifiche INTEGER
	);
	
	INSERT INTO temp
	SELECT *
	FROM persona
	WHERE CF LIKE CONCAT(trecifre, '%');
END //
delimiter ; */
/*
-- 3
delimiter //
CREATE PROCEDURE if NOT EXISTS op3(IN anno INTEGER)
BEGIN
	DROP TEMPORARY TABLE temp
	CREATE TEMPORARY TABLE temp(
		Codice INTEGER PRIMARY KEY,
		Nome VARCHAR(30),
		Importanza INTEGER, 
		AnnoIntroduzione INTEGER,
		CompetenzaAcquisita INTEGER,
		N_Persone INTEGER		
	);
	
	INSERT INTO temp
	SELECT *
	FROM qualifica
	WHERE annoIntroduzione = anno;
END //
delimiter ; */
/* 
-- 4
delimiter //
CREATE PROCEDURE if NOT EXISTS op4(IN nome_competenza VARCHAR(255))
BEGIN
	DROP TEMPORARY TABLE if EXISTS temp;
	CREATE TEMPORARY TABLE temp(
		CF VARCHAR(16),
		Nome VARCHAR(255),
		Cognome VARCHAR(255),
		DataNascita DATE,
		Indirizzo VARCHAR(255),
		N_qualifiche INTEGER	
	);
	
	INSERT INTO temp
	SELECT p.*
	FROM persona p
	JOIN attestato a ON p.CF = a.Persona
	JOIN qualifica q ON a.Qualifica = q.Codice
	JOIN competenza c ON q.CompetenzaAcquisita = c.Codice
	WHERE c.Nome = nome_competenza;
END //
delimiter ;

CALL op4('informatica');
SELECT * FROM temp; */
/*
-- 5
delimiter //
CREATE PROCEDURE if NOT EXISTS op5(IN anno_input INTEGER)
BEGIN
	DROP TEMPORARY TABLE if EXISTS temp;
	CREATE TEMPORARY TABLE temp(
		anno INTEGER,
		n_qualifiche INTEGER
	);
	
	INSERT INTO temp
	SELECT annoIntroduzione, COUNT(*) AS NumeroQualifiche
	FROM qualifica	
	where annoIntroduzione >= anno_input
	GROUP BY annoIntroduzione;
END //
delimiter ;
CALL op5('1998');
SELECT * FROM temp; */
/*
-- 6
CREATE VIEW if NOT EXISTS numero_attestati AS
	SELECT COUNT(*) AS n_attestati, YEAR(DATA) AS anno
	FROM attestato
	GROUP BY anno;
	
SELECT SUM(n_attestati)/(YEAR(CURRENT_DATE())-MIN(anno)+1) AS NumMedioAnnuoAttestati
FROM numero_attestati; */
/* 
-- 7
delimiter //
CREATE PROCEDURE if NOT EXISTS op7(IN anno_i INTEGER)
BEGIN
	DROP TEMPORARY TABLE if EXISTS temp;
	CREATE TEMPORARY TABLE temp(
		anno INTEGER
	);
	
	while anno_i <= (SELECT MAX(annoIntroduzione) FROM qualifica) do
		INSERT INTO temp 
		SELECT anno_i;
		SET anno_i = anno_i + 1;
	END while;
	
	DROP TEMPORARY TABLE if EXISTS temp1;
	CREATE TEMPORARY TABLE temp1(
		n_qualifiche INTEGER,
		anno INTEGER 
	);
	
	INSERT INTO temp1
	SELECT COUNT(q.AnnoIntroduzione), q.AnnoIntroduzione
	FROM qualifica q
	RIGHT JOIN temp t ON q.AnnoIntroduzione = t.anno
	GROUP BY q.AnnoIntroduzione;
END //
delimiter ; */
/*
-- 8
CREATE VIEW if NOT EXISTS op8 AS
	SELECT p.*
	FROM persona p
	JOIN attestato a ON p.CF = a.Persona
	JOIN qualifica q ON a.Qualifica = q.Codice
	WHERE q.Importanza = (SELECT MAX(Importanza) FROM qualifica); */
/*
-- 9
CREATE VIEW if NOT EXISTS op9 AS
	SELECT p.*, a.Qualifica
	FROM persona p
	JOIN attestato a ON p.CF = a.Persona
	WHERE NOT EXISTS (SELECT * FROM uso u WHERE u.Persona = p.CF AND u.Qualifica = a.Qualifica) */
/*
-- 10
CREATE VIEW if NOT EXISTS op10 AS
	SELECT YEAR(u.Data) - YEAR(a.Data) AS Differenza
	FROM attestato a
	JOIN uso u ON a.Qualifica = u.Qualifica AND a.Persona = u.Persona;
	
SELECT AVG(Differenza) FROM op10; */
/* 
-- 11
delimiter //
CREATE TRIGGER UpdateQualifichePerPersona
AFTER INSERT INTO attestato
FOR EACH ROW
BEGIN
	if EXISTS (SELECT * FROM qualifica WHERE Codice = NEW.qualifica)
	then 
		UPDATE qualifica
		SET n_persone = n_persone + 1
		WHERE qualifica.Codice = NEW.qualifica
	END if;
	
	if EXISTS (SELECT * FROM persona WHERE CF = NEW.persona)
	then
		UPDATE persona
		SET n_qualifiche = n_qualifiche + 1
		WHERE persona.CF = NEW.persona
	END if;
END //
delimiter ; */


