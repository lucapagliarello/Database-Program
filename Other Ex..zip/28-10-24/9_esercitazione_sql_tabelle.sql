CREATE DATABASE if not exists esercitazione9;
USE esercitazione9;

CREATE TABLE if not exists PERSONA
(
	CF VARCHAR(16) PRIMARY KEY,
	Nome VARCHAR(255),
	Cognome VARCHAR(255),
	DataNascita DATE,
	Indirizzo VARCHAR(255),
	N_qualifiche INTEGER
);

CREATE TABLE if not exists COMPETENZA
(
	Codice INTEGER PRIMARY KEY,
	Nome VARCHAR(255), 
	Tipo VARCHAR(255)
);

CREATE TABLE if not exists QUALIFICA
(
	Codice INTEGER PRIMARY KEY,
	Nome VARCHAR(30),
	Importanza INTEGER, 
	AnnoIntroduzione INTEGER,
	CompetenzaAcquisita INTEGER,
	N_Persone INTEGER,
	FOREIGN KEY (CompetenzaAcquisita) REFERENCES COMPETENZA(Codice)
);

CREATE TABLE if not exists ATTESTATO
(
	Persona VARCHAR(16),
	Qualifica INTEGER,
	Data DATE,
	FOREIGN KEY(Persona) REFERENCES PERSONA(CF),
	FOREIGN KEY(Qualifica) REFERENCES QUALIFICA(Codice),
	PRIMARY KEY(Persona,qualifica)
);


CREATE TABLE if not exists USO
(
Persona VARCHAR(16),
Qualifica INTEGER,
Data DATE,
FOREIGN KEY(Persona) REFERENCES PERSONA(CF),
FOREIGN KEY(Qualifica) REFERENCES QUALIFICA(Codice),
PRIMARY KEY(Persona,Qualifica)
);