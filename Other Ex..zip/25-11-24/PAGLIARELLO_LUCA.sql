CREATE TABLE if NOT EXISTS PERSONA(
	Id INTEGER PRIMARY KEY,
	Nome VARCHAR(255),
	Cognome VARCHAR(255),
	Anno_nascita YEAR,
	indirizzo VARCHAR(255)
);

CREATE TABLE if NOT EXISTS MACCHINA(
	Targa VARCHAR(255) PRIMARY KEY,
	Modello VARCHAR(255),
	Anno YEAR
);

CREATE TABLE if NOT EXISTS INCIDENTE(
	Numero INTEGER PRIMARY KEY,
	DATA1 DATE,
	Luogo VARCHAR(255)
);

CREATE TABLE if NOT EXISTS PROPRIETARI(
	Id_persona INTEGER,
	Targa VARCHAR(255),
	PRIMARY KEY(Id_persona, Targa),
	FOREIGN KEY (Id_persona) REFERENCES PERSONA(Id),
   FOREIGN KEY (Targa) REFERENCES MACCHINA(Targa)
);

CREATE TABLE if NOT EXISTS PARTECIPA(
	Id_persona INTEGER,
	Macchina VARCHAR(255),
	Numero_incidente INTEGER,
	Costo INTEGER,
	PRIMARY KEY(Id_persona, Macchina, Numero_incidente),
   FOREIGN KEY (Id_persona) REFERENCES PERSONA(Id),
   FOREIGN KEY (Macchina) REFERENCES MACCHINA(Targa),
   FOREIGN KEY (Numero_incidente) REFERENCES INCIDENTE(Numero)
);

CREATE VIEW if NOT EXISTS op1 AS
	SELECT i.Luogo AS Luogo, i.DATA1 AS DATA, COUNT(i.Numero) AS Numero_totale, SUM(p.Costo) AS Costo_totale
	FROM incidente i
	JOIN partecipa p ON i.Numero = p.Numero_incidente
	GROUP BY i.Luogo, i.DATA1

delimiter //
CREATE PROCEDURE if NOT EXISTS op2(IN anno_input YEAR)
BEGIN
	DROP TEMPORARY TABLE if EXISTS temp;
	CREATE TEMPORARY TABLE if NOT EXISTS temp(
		id INTEGER,
		costo INTEGER,
		anno YEAR
	);
	
	INSERT INTO temp
	SELECT p.Id, MAX(pa.Costo), i.DATA1
	FROM persona p
	JOIN partecipa pa ON p.Id = pa.Id_persona
	JOIN incidente i ON pa.Numero_incidente = i.Numero
	WHERE YEAR(i.DATA1) = anno_input;
END //

delimiter //
CREATE PROCEDURE if NOT EXISTS op3(IN luogo_input VARCHAR(255), OUT costo_totale INTEGER)
BEGIN
	DROP TEMPORARY TABLE if EXISTS temp;
	CREATE TEMPORARY talbe if NOT EXISTS temp(
		costo INTEGER,
		anno YEAR,
		luogo VARCHAR(255)
	);
	
	INSERT INTO temp
	SELECT SUM(pa.Costo), YEAR(i.DATA1), i.Luogo
	FROM partecipa pa
	JOIN incidente i ON pa.Numero_incidente = i.Numero AND i.Luogo = luogo_input
	GROUP BY YEAR(i.DATA1);
	
	SELECT SUM(pa.Costo)
	INTO costo_totale
	FROM partecipa pa;
END //
	
delimiter //
CREATE PROCEDURE if NOT EXISTS op4(IN citta VARCHAR(255))
BEGIN
	SELECT AVG(Numero_totale) AS Numero_Medio, AVG(Costo_totale) AS Costo_medio, Luogo
	FROM op1
	WHERE Luogo = citta;
END //

delimiter //
CREATE PROCEDURE if NOT EXISTS op5(IN id_input INTEGER)
BEGIN
	DROP TEMPORARY TABLE if EXISTS temp;
	CREATE TEMPORARY TABLE if NOT EXISTS temp(
		id INTEGER,
		numero_incidente INTEGER,
		DATA1 INTEGER,
		luogo VARCHAR(255)
	);
	
	INSERT INTO temp
	SELECT pe.Id, i.*
	FROM incidente i
	JOIN partecipa p ON i.Numero = p.Numero_incidente
	JOIN persona pe ON p.Id_persona = pe.Id
	WHERE pe.Id = id_input;
END //

CREATE PROCEDURE if NOT EXISTS op6(IN numero_inc INTEGER)
BEGIN
	SELECT m.Targa, m.Modello, p.Numero_incidente
	FROM macchina m 
	FROM partecipa p ON m.Targa = p.Macchina
	WHERE p.Numero_incidente = numero_inc;
END //

