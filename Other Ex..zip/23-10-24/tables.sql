create TABLE if NOT EXISTS attori(
codAttore integer primary key,
nome varchar(255),
annoNascita integer,
nazionalita varchar(255)
);  

create table if NOT EXISTS film(
codFilm integer primary key,
titolo varchar(255),
annoProduzione integer,
nazionalita varchar(255),
regista varchar(255),
genere varchar(255)
); 

create table if NOT EXISTS sale(
codSala integer primary key,
posti integer,
nome varchar(255),
citta varchar(255)
); 

create table if NOT EXISTS recita(
codAttore integer,
codFilm integer,
foreign key(codAttore) references attori(codAttore),
foreign key(codFilm) references film(codFilm),
primary key(codAttore,codFilm)
); 

create table if NOT EXISTS proiezioni(
codProiezione integer primary key,
codFilm integer,
codSala integer,
incasso float,
dataProiezione date,
foreign key(codFilm) references film(codFilm),
foreign key(codSala) references sale(codSala)
);