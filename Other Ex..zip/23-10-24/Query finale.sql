CREATE DATABASE if NOT EXISTS esercitazione_23_10_v2;
USE esercitazione_23_10_v2;

CREATE TABLE if NOT EXISTS attori(
	codAttore integer primary key,
	nome varchar(255),
	annoNascita integer,
	nazionalita varchar(255)
);  

CREATE TABLE if NOT EXISTS film(
	codFilm integer primary key,
	titolo varchar(255),
	annoProduzione integer,
	nazionalita varchar(255),
	regista varchar(255),
	genere varchar(255)
); 

CREATE TABLE if NOT EXISTS sale(
	codSala integer primary key,
	posti integer,
	nome varchar(255),
	citta varchar(255)
); 

CREATE TABLE if NOT EXISTS recita(
	codAttore integer,
	codFilm integer,
	foreign key(codAttore) references attori(codAttore),
	foreign key(codFilm) references film(codFilm),
	primary key(codAttore,codFilm)
); 

CREATE TABLE if NOT EXISTS proiezioni(
	codProiezione integer primary key,
	codFilm integer,
	codSala integer,
	incasso float,
	dataProiezione date,
	foreign key(codFilm) references film(codFilm),
	foreign key(codSala) references sale(codSala)
);
/*
-- 1
DELIMITER //
CREATE PROCEDURE if NOT EXISTS op1(IN citta VARCHAR(255))
BEGIN
	DROP TEMPORARY TABLE if EXISTS temp;
	CREATE TEMPORARY TABLE temp (
		nome VARCHAR(255)
	);
	
	INSERT INTO temp
	SELECT s.nome
	FROM sale s
	WHERE s.citta = citta;
END //
DELIMITER ;
CALL op1('Roma');
SELECT * FROM temp; */
/*
-- 2
DELIMITER //
CREATE PROCEDURE if NOT EXISTS op2(IN giorno DATE)
BEGIN
	DROP TEMPORARY TABLE if EXISTS temp;
	CREATE TEMPORARY TABLE temp(
		titolo VARCHAR(255),
		genere VARCHAR(255)
	);
	
	INSERT INTO temp
	SELECT f.titolo, f.genere
	FROM film f
	JOIN proiezioni p ON f.codFilm = p.codFilm
	WHERE p.dataProiezione = giorno;
END //
DELIMITER ;
CALL op2('2017-12-11');
SELECT * FROM temp; */
/*
-- 3
DELIMITER //
CREATE PROCEDURE if NOT EXISTS op3 (IN attore1 VARCHAR(255), IN attore2 VARCHAR(255))
BEGIN
	DROP VIEW if EXISTS attoreRecita;
	CREATE VIEW if NOT EXISTS attoreRecita(codAttore, codFilm, nome) as
	SELECT a.codAttore, a.nome, r.codFilm
	FROM attori a
	JOIN recita r ON a.codAttore = r.codFilm;
	
	SELECT f.titolo
	FROM (attoreRecita ar1
			JOIN attoreRecita ar2
			ON ar1.codFilm = ar2.codFilm)
	JOIN film f ON ar1.codFilm = f.codFilm
	WHERE ar1.nome = attore1 AND ar2.nome = attore2;
END //
DELIMITER ;
CALL op3('Jean Reno', 'Will Smith');*/
/*
-- 4
DELIMITER //
CREATE PROCEDURE if NOT EXISTS op4(IN regista VARCHAR(255), IN citta VARCHAR(255))
BEGIN
	SELECT f.titolo, COUNT(*) AS NumeroProiezioni, SUM(incasso) AS IncassoTotale
	FROM film f
	JOIN proiezioni p ON f.codFilm = p.codFilm
	WHERE f.regista = regista AND p.codSala IN (SELECT codSala
															  FROM sale s
															  WHERE s.citta = citta)
	GROUP BY f.titolo, f.codFilm;
END //
DELIMITER ; */
/*
-- 5
DELIMITER //
CREATE PROCEDURE if NOT EXISTS op5(IN citta VARCHAR(255))
BEGIN
	START TRANSACTION; -- un insieme di operazioni SQL che devono essere eseguite come un blocco unico e atomico
		DROP TEMPORARY TABLE if EXISTS temp1;
		CREATE TEMPORARY TABLE temp1 (
			titolo VARCHAR(255)
		);
		
		DROP TEMPORARY TABLE if EXISTS temp2;
		CREATE TEMPORARY TABLE temp2 (
			titolo VARCHAR(255)
		);
		
		INSERT INTO temp1
		SELECT f.titolo
		FROM film f
		WHERE f.codFilm NOT IN(SELECT p.codFilm
									  FROM proiezioni p
									  JOIN sale s
									  ON p.codSala = p.codSala
									  WHERE s.citta = 'Roma');
		
		INSERT INTO temp2
		SELECT DISTINCT f.titolo
		FROM film f
		JOIN proiezioni p ON f.codFilm = p.codFilm
		JOIN sale s ON s.codSala = p.codSala
		WHERE f.codFilm NOT IN(SELECT p.codFilm
									  FROM proiezioni p
									  JOIN sale s
									  ON p.codSala = p.codSala
									  WHERE s.citta <> 'Roma')
		AND s.citta = 'Roma';
	COMMIT;
END //
DELIMITER ; */
/*
-- 6
DELIMITER //
CREATE PROCEDURE if NOT EXISTS op6(IN nazionalita VARCHAR(255), IN regista VARCHAR(255))
BEGIN
	DROP TEMPORARY TABLE if EXISTS temp;
	CREATE TEMPORARY TABLE temp (
		nome VARCHAR(255)
	);
	
	INSERT INTO temp
	SELECT a.nome
	FROM attori a
	WHERE a.nazionalita = 'Italia'
	AND a.codAttore NOT IN (SELECT r.codAttore
									FROM film f
									JOIN recita r
									ON f.codFilm = r.codFilm
									WHERE f.regista = 'Steven Spielberg')

END //
DELIMITER ; */

-- 7
CREATE TABLE IF NOT EXISTS stats_film (
	codFilm INTEGER PRIMARY KEY,
	numAttori INTEGER,
	numCittaProiezioni INTEGER,
	totIncasso DOUBLE
);

CREATE VIEW if NOT EXISTS numAttoriFilm AS
	SELECT codFilm, COUNT(*) AS numAttori
	FROM recita
	GROUP BY codFilm;
	
CREATE VIEW if NOT EXISTS numCittaIncassoFilm AS
	SELECT codFilm, COUNT(DISTINCT citta) AS numCitta, SUM(incasso) AS totIncasso
	FROM proiezioni p
	JOIN sale s ON p.codSala = s.codSala
	GROUP BY codFilm;
	
INSERT INTO stats_film
	SELECT nA.codFilm, numAttori, numCitta, totIncasso
	FROM numAttoriFilm nA
	JOIN numCittaIncassoFilm nC ON nA.codFilm = nC.codFilm
	
DELIMITER //
CREATE TRIGGER AggiornaStatsFilmProiezioni
BEFORE INSERT ON proiezioni
FOR EACH ROW
BEGIN
	if NOT EXISTS (SELECT * FROM stats_film WHERE codFilm = NEW.codFilm)
	then
		INSERT INTO stats_film
		SELECT NEW.codFilm, (SELECT COUNT(*)
										FROM recita
										WHERE codFilm = NEW.codFilm), 1, NEW.incasso;
	else
		if EXISTS (SELECT *
					  FROM proiezioni p
					  JOIN sale s ON p.codSala = s.codSala
					  WHERE p.codFilm = NEW.codFilm
					  AND citta = (SELECT citta
					  					FROM sale
					  					WHERE codSala = NEW.codSala)
					  	)
		then
			UPDATE stats_film
			SET totIncasso = totIncasso + NEW.incasso
			WHERE codFilm = NEW.codFilm;
	 	else
	 		UPDATE stats_film
	 		SET numCittaProiezioni = numCittaProiezioni + 1, 
			totIncasso = totIncasso + NEW.incasso
			WHERE codFilm = NEW.codFilm;
		END if;
	END if;							
END //

CREATE TRIGGER AggiornaStatsFilmAttori
AFTER INSERT ON recita
FOR EACH ROW
BEGIN
	if NOT EXISTS (SELECT * FROM stats_film WHERE codFilm = NEW.codFilm)
	then
		INSERT INTO stats_film
		SELECT NEW.codFilm, 1, (SELECT COUNT(DISTINCT citta) 
										FROM proiezioni P 
										JOIN sale s ON p.codSala = s.codSala
										WHERE p.codFilm = NEW.codFilm), 
										(SELECT SUM(incasso)
										FROM proiezioni p
										WHERE p.codFilm = NEW.codFilm);
	ELSE
		UPDATE stats_film
		SET numAttori = numAttori + 1
		WHERE codFilm = NEW.codFilm;
	END if;
END //

CREATE TABLE stats_attori (
	codAttore INTEGER PRIMARY KEY,
	cognomeNome VARCHAR(255),
	numFilm INTEGER
);

INSERT INTO stats_attori
SELECT a.codAttore , a.nome, COUNT(*) AS numFilm
FROM attori a
JOIN recita r ON a.codAttore = r.codAttore
GROUP BY a.codAttore;

DROP TRIGGER if EXISTS AggiornaStatsFilmAttori;

CREATE TRIGGER AggiornaStatsAttori
AFTER INSERT ON recita
FOR EACH ROW
BEGIN
	if EXISTS (SELECT codAttore
				  FROM stats_attori
				  WHERE codAttore = NEW.codAttore)
	then
		UPDATE stats_attori
		SET numFilm = numFilm + 1
		WHERE codAttore = NEW.codAttore;
	ELSE
		INSERT INTO stats_attori
		SELECT NEW.codAttore, (SELECT nome
									  FROM attori
									  WHERE codAttore = NEW.codAttore), 1;
	END if;
END //
DELIMITER ;



