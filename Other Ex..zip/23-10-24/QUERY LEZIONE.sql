-- DELIMITER \\
/* 
1
CREATE PROCEDURE IF NOT EXISTS op1 (IN citta VARCHAR(255))
BEGIN
	DROP TEMPORARY TABLE IF EXISTS tmp;
	CREATE TEMPORARY TABLE tmp(
		nome VARCHAR(255)
	);
	
	INSERT INTO tmp
	SELECT nome
	FROM sale
	WHERE sale.citta = citta; -- il primo rappresenta la citta della tabella creata mentre il secondo rappresenta il valore passato in input
END \\
DELIMITER ;

CALL op1('Roma');
SELECT * FROM tmp

2
CREATE PROCEDURE IF NOT EXISTS op2 (IN giorno DATE)
BEGIN
	DROP TEMPORARY TABLE IF EXISTS temp;
	CREATE TEMPORARY TABLE temp(
		titolo VARCHAR(255),
		genere VARCHAR(255)
	);
	
	INSERT INTO temp
	SELECT film.titolo, film.genere
	FROM film 
	JOIN proiezioni ON film.codFilm = proiezioni.codFilm
	WHERE proiezioni.dataProiezione = giorno;
END \\
DELIMITER ;

CALL op2('2017-12-11');
SELECT * FROM temp

DROP PROCEDURE IF EXISTS op3;
CREATE PROCEDURE IF NOT EXISTS op3 (IN attore1 VARCHAR(255), attore2 VARCHAR(255))
BEGIN
	DROP TEMPORARY TABLE IF EXISTS temp1;
	CREATE TEMPORARY TABLE temp1(
		titolo VARCHAR(255)
	);
	
	INSERT INTO temp1
	SELECT titolo
	FROM attori A 
	JOIN recita R ON A.codAttore = R.codAttore
	JOIN film F ON R.codFilm = F.codFilm
	WHERE A.nome = attore1 AND F.codFilm = ANY(
		SELECT R1.codFilm
		FROM attori A1 JOIN recita R1 ON A1.codAttore = R1.codAttore
		WHERE A1.nome = attore2);
	
END \\
DELIMITER ;

CALL op3('Jean Reno', 'Will Smith');
SELECT * FROM temp1
*/


-- 7
CREATE TABLE IF NOT EXISTS stats_film (
	Cod_Film INTEGER PRIMARY KEY,
	N_Attori INTEGER,
	N_Citta_proiezioni INTEGER,
	tot_incasso DOUBLE
);

CREATE VIEW IF NOT EXISTS numAttoriFilm AS
SELECT codFilm, COUNT(*) AS NumAttori
FROM recita
GROUP BY codFilm;

CREATE VIEW IF NOT EXISTS numCitta_incassoFilm AS
SELECT codFilm, COUNT(DISTINCT citta) AS NumCitta, SUM(incasso) AS totIncasso
FROM proiezioni p 
JOIN sale s ON p.codSala = s.codSala
GROUP BY codFilm;

INSERT INTO stats_film
SELECT N1.codFilm, numAttori, numCitta, totIncasso
FROM numAttoriFilm N1
JOIN numCitta_incassoFilm N2 ON N1.codFilm = N2.codFilm;

DELIMITER //
CREATE TRIGGER aggiornaStatsFilmProiezioni
AFTER INSERT ON recita 
FOR EACH ROW 
BEGIN 
	IF NOT EXISTS(SELECT * FROM stats_films WHERE codFilm = NEW.codFilm) 
	then INSERT INTO stats_films
	SELECT NEW.codFilm, 1, (SELECT COUNT(DISTINCT citta) 
									FROM proiezioni P 
									JOIN sale s ON p.codSala = s.codSala
									WHERE p.codFilm = NEW.codFilm), 
									(SELECT SUM(incasso)
									FROM proiezioni p
									WHERE p.codFilm = NEW.codFilm)
	ELSE
		UPDATE stats_films
		SET numAttori = numAttori + 1
		WHERE codFilm = NEW.codFilm
	END IF;

END //
DELIMITER ;