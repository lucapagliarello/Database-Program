CREATE TABLE ATTORI IF NOT EXISTS(
    CodAttore INTEGER PRIMARY KEY,
    Nome VARCHAR(255) NOT NULL,
    AnnoNascita YEAR NOT NULL,
    Nazionalità VARCHAR(255) NOT NULL
);

CREATE TABLE FILM IF NOT EXISTS (
    CodFilm INTEGER PRIMARY KEY,
    Titolo VARCHAR(255) NOT NULL,
    AnnoProduzione YEAR NOT NULL,
    Nazionalità VARCHAR(255) NOT NULL,
    Regista VARCHAR(255) NOT NULL,
    Genere VARCHAR(255) NOT NULL
);

CREATE TABLE SALE IF NOT EXISTS (
    CodSala INTEGER PRIMARY KEY,
    Posti INTEGER NOT NULL,
    Nome VARCHAR(255) NOT NULL,
    Città VARCHAR(255) NOT NULL
);

CREATE TABLE RECITA IF NOT EXISTS (
    CodAttore INTEGER,
    CodFilm INTEGER,
    PRIMARY KEY (CodAttore, CodFilm),
    FOREIGN KEY (CodAttore) REFERENCES ATTORI(CodAttore)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY (CodFilm) REFERENCES FILM(CodFilm)
        ON DELETE SET NULL
        ON UPDATE NO ACTION
);

CREATE TABLE PROIEZIONI IF NOT EXISTS (
    CodProiezione INTEGER PRIMARY KEY,
    CodFilm INTEGER NOT NULL,
    CodSala INTEGER NOT NULL,
    Incasso FLOAT NOT NULL,
    DataProiezione DATE NOT NULL,
    FOREIGN KEY (CodFilm) REFERENCES FILM(CodFilm)
        ON DELETE SET NULL
        ON UPDATE NO ACTION,
    FOREIGN KEY (CodSala) REFERENCES SALE(CodSala)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

DELIMITER //

-- Trigger per impedire l'inserimento di una proiezione senza il codice del Film
CREATE TRIGGER Check_codice_nullo
BEFORE INSERT ON PROIEZIONI
FOR EACH ROW
BEGIN
    IF NEW.CodFilm IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Errore: CodFilm non può essere NULL nella tabella PROIEZIONI.';
    END IF;
END //

-- Trigger per impedire l'inserimento di una proiezione senza CodSala
CREATE TRIGGER Check_codicesala_nullo
BEFORE INSERT ON PROIEZIONI
FOR EACH ROW
BEGIN
    IF NEW.CodSala IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Errore: CodSala non può essere NULL nella tabella PROIEZIONI.';
    END IF;
END //

-- Trigger per evitare che l'Incasso sia negativo in PROIEZIONI
CREATE TRIGGER Check_Incasso_nonegativo
BEFORE INSERT ON PROIEZIONI
FOR EACH ROW
BEGIN
    IF NEW.Incasso < 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Errore: L\'incasso non può essere negativo nella tabella PROIEZIONI.';
    END IF;
END //

DELIMITER ;


