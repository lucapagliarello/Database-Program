CREATE DATABASE homework2;
USE homework2;

CREATE TABLE IMPIEGATO(
	ID INTEGER PRIMARY KEY, 
	nome VARCHAR (20),
	cognome VARCHAR (20),
	anno INTEGER,
	indirizzo VARCHAR (50),
	citta VARCHAR (20)
);

CREATE TABLE AZIENDA(
	nome VARCHAR (20) PRIMARY KEY,
	citta VARCHAR (20)
);


CREATE TABLE LAVORA(
	id_impiegato INTEGER, 
	azienda VARCHAR (20),
	salario INTEGER,
	PRIMARY KEY(id_impiegato, azienda),
	FOREIGN KEY (id_impiegato) REFERENCES IMPIEGATO(ID),
	FOREIGN KEY (azienda) REFERENCES AZIENDA(nome)
);

CREATE TABLE CAPI(
	id_impiegato INTEGER PRIMARY KEY, 
	id_capo INTEGER,
	FOREIGN KEY (id_impiegato) REFERENCES IMPIEGATO(ID),
	FOREIGN KEY (id_capo) REFERENCES IMPIEGATO(ID)
);

insert into IMPIEGATO values ('1','Luca','Rossi','1970','Via Firenze','Torino');
insert into IMPIEGATO values ('2','Giacomo','Verdi','1980','Via Milano','Catania');
insert into IMPIEGATO values ('3','Luca','Felice','1970','Via Pasubio','Milano');
insert into IMPIEGATO values ('4','Gigi','La Trottola','1983','Via Alcide De Gasperi','Torino');
insert into IMPIEGATO values ('5','Mino','Reitano','1959','Via Messina ','Catania');
insert into IMPIEGATO values ('6','Francesco','Turiano','1967','Via Messina','Torino');
insert into IMPIEGATO values ('7','Giuseppe','Turiano','1973','Via Mele','Torino');
insert into IMPIEGATO values ('8','Luciano','Ligabue','1965','Via Peppoli','Catania');
insert into IMPIEGATO values ('9','Francesco','Tramonatana','1937','Via Pinco','Milano');
insert into IMPIEGATO values ('10','Francesco','Turiano','1942','Via Hotel','Catania');
insert into IMPIEGATO values ('11','Luca','Infelice','1965','Via Pasubio','Milano');
insert into IMPIEGATO values ('12','Carlo','Trottola','1980','Via Alcide De Gasperi','Torino');
insert into IMPIEGATO values ('13','Beppe','Reitano','1937','Via Messina ','Catania');
insert into IMPIEGATO values ('14','Francisco','Loi','1947','Via Messina','Torino');
insert into IMPIEGATO values ('15','Pino','Ignoto','1957','Via Mele','Torino');
insert into IMPIEGATO values ('16','Luciano','Lima','1965','Via Peppoli','Catania');
insert into IMPIEGATO values ('17','Ester','Tramonatana','1978','Via Pinco','Milano');
insert into IMPIEGATO values ('18','Francesca','Coco','1967','Via Hotel','Catania');
insert into IMPIEGATO values ('21','Francesca','Coco','1967','Via Hotel','Catania');

insert into AZIENDA values ('FASTWEB','Milano');
insert into AZIENDA values ('TELECOM','Torino');
insert into AZIENDA values ('MORGAN STANLEY','Catania');
insert into AZIENDA values ('CISCO','Catania');
insert into AZIENDA values ('ACCENTURE','Milano');
insert into AZIENDA values ('FIAT','Torino');
insert into LAVORA values (1,'FASTWEB',10000);
insert into LAVORA values (2,'FASTWEB',20583);
insert into LAVORA values (3,'TELECOM',65783);
insert into LAVORA values (4,'CISCO',78547);
insert into LAVORA values (5,'TELECOM',6743);
insert into LAVORA values (6,'MORGAN STANLEY',78345);
insert into LAVORA values (7,'CISCO',7854);
insert into LAVORA values (8,'TELECOM',78356);
insert into LAVORA values (9,'TELECOM',23432);
insert into LAVORA values (10,'FIAT',56433);
insert into LAVORA values (11,'MORGAN STANLEY',76533);
insert into LAVORA values (12,'MORGAN STANLEY',64332);
insert into LAVORA values (13,'CISCO',23500);
insert into LAVORA values (14,'CISCO',43000);
insert into LAVORA values (15,'FASTWEB',22000);
insert into LAVORA values (16,'FIAT',12500);
insert into LAVORA values (17,'FIAT',54363);
insert into LAVORA values (18,'FIAT',23456);

insert into CAPI values (15,1);
insert into CAPI values (2,1);
insert into CAPI values (5,3);
insert into CAPI values (8,3);
insert into CAPI values (9,3);
insert into CAPI values (7,4);
insert into CAPI values (4,13);
insert into CAPI values (6,11);
insert into CAPI values (11,12);
insert into CAPI values (16,18);
insert into CAPI values (17,18);

-- 1 PUNTO RICHIESTO
SELECT i1.nome AS impiegato_nome, i1.cognome AS impiegato_cognome, 
       i2.nome AS capo_nome, i2.cognome AS capo_cognome
FROM capi 
JOIN impiegato i1 ON capi.id_impiegato = i1.ID
JOIN impiegato i2 ON capi.id_capo = i2.ID;

-- 2 PUNTO RICHIESTO
SELECT i1.nome, i1.cognome, i2.nome, i2.cognome, l1.azienda
FROM impiegato AS i1 
JOIN impiegato AS i2 
JOIN capi AS c 
JOIN lavora AS l1 
JOIN lavora AS l2
ON i1.ID = c.id_impiegato AND i1.ID = l1.id_impiegato 
AND i2.ID = c.id_capo AND i2.ID = l2.id_impiegato 
WHERE l1.azienda = l2.azienda;

-- 3 PUNTO RICHIESTO
SELECT i1.nome, i1.cognome, l1.salario
FROM impiegato AS i1
JOIN impiegato AS i2
JOIN capi
JOIN lavora AS l1
JOIN lavora AS l2
ON i1.ID = capi.id_impiegato AND i1.ID = l1.id_impiegato
AND i2.ID = capi.id_capo AND i2.ID = l2.id_impiegato
WHERE l1.salario > l2.salario

-- 4 PUNTO RICHIESTO
SELECT i.* 
FROM impiegato AS i
JOIN lavora ON i.ID = lavora.id_impiegato
JOIN azienda ON azienda.nome = lavora.azienda
WHERE i.anno >= 1960 AND i.anno <= 1970
	AND azienda.citta = 'Milano'
	AND i.citta = 'Catania';

