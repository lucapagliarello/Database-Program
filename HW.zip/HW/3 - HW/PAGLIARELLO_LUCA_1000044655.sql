-- ESERCIZIO 1
CREATE DATABASE homework3;
USE homework3;

CREATE TABLE FACOLTA (
	Codice_Fac INTEGER PRIMARY KEY,
	Nome VARCHAR(255),
	Indirizzo_Sede VARCHAR(255),
	N_Telefonico VARCHAR(255)
);

CREATE TABLE CORSO_DI_LAUREA (
	Codice_CdL INTEGER PRIMARY KEY,
	Nome VARCHAR(255),
	Cod_Fac INTEGER,
	FOREIGN KEY (Cod_Fac) REFERENCES FACOLTA(Codice_Fac)
);

CREATE TABLE STUDENTI (
	Matricola INTEGER PRIMARY KEY,
	Nome VARCHAR(255),
	Cognome VARCHAR(255),
	DataNascita DATE,
	Indirizzo VARCHAR(255),
	Telefono VARCHAR(255),
	Cod_CorsoDiLaurea INTEGER,
	FOREIGN KEY (Cod_CorsoDiLaurea) REFERENCES CORSO_DI_LAUREA(Codice_CdL)
);

CREATE TABLE DOCENTI (
	Codice_Docente INTEGER PRIMARY KEY,
	Nome VARCHAR(255),
	Cognome VARCHAR(255)
);

CREATE TABLE INSEGNAMENTO (
	Codice_Insegnamento INTEGER PRIMARY KEY,
	Nome VARCHAR(255),
	Cod_Docente INTEGER,
	Codice_CdL INTEGER,
	FOREIGN KEY (Cod_Docente) REFERENCES DOCENTI(Codice_Docente),
	FOREIGN KEY (Codice_CdL) REFERENCES CORSO_DI_LAUREA(Codice_CdL)
);

CREATE TABLE ESAMI (
	MatrStud INTEGER,
	Voto INTEGER,
	data_esame DATE,
	Lode BOOLEAN,
	Cod_Ins INTEGER,
	PRIMARY KEY(MatrStud, Cod_Ins),
	FOREIGN KEY (MatrStud) REFERENCES studenti(Matricola),
	FOREIGN KEY (Cod_Ins) REFERENCES insegnamento(Codice_Insegnamento)
);

/1/
SELECT c.Nome AS CorsoDiLaurea, COUNT(s.Matricola) AS NumeroIscritti
FROM studenti s
JOIN corso_di_laurea c ON s.Cod_CorsoDiLaurea = c.Codice_CdL
GROUP BY c.Nome

/2/
SELECT i.Nome AS Insegnamento
FROM insegnamento i
JOIN corso_di_laurea c ON i.Codice_CdL = c.Codice_CdL
JOIN facolta f ON f.Codice_Fac = c.Cod_Fac
WHERE f.Nome = 'Ingegneria'
ORDER BY i.Nome ASC;

/3/
SELECT i.Nome AS insegnamento, COUNT(e.MatrStud) AS NumeroEsami
FROM insegnamento i
JOIN corso_di_laurea c ON i.Codice_CdL = c.Codice_CdL
JOIN esami e ON e.Cod_Ins = i.Codice_Insegnamento
WHERE c.Nome = 'Informatica' AND YEAR(e.data_esame) = 2001
GROUP BY i.Nome
ORDER BY NumeroEsami DESC;

/4/
SELECT DISTINCT s.Matricola, s.Cognome, s.Nome
FROM studenti s
JOIN esami e ON s.Matricola = e.MatrStud
ORDER BY s.Cognome ASC, s.Nome ASC;

-- ESERCIZIO 2
CREATE DATABASE homework3_2;
USE homework3_2;

CREATE TABLE STADIO (
	Nome VARCHAR(255) PRIMARY KEY,
	Citta VARCHAR(255),
	Capienza INTEGER
);

CREATE TABLE INCONTRO (
	NomeStadio VARCHAR(255),
	DataIncontro DATE,
	Ora TIME,
	Squadra1 VARCHAR(255),
	Squadra2 VARCHAR(255),
	PRIMARY KEY(NomeStadio, DataIncontro, Ora),
	FOREIGN KEY (NomeStadio) REFERENCES STADIO(Nome),
	FOREIGN KEY (Squadra1) REFERENCES nazionale(Paese),
	FOREIGN KEY (Squadra2) REFERENCES nazionale(Paese)
);

CREATE TABLE NAZIONALE (
	Paese VARCHAR(255) PRIMARY KEY,
	Continente VARCHAR(255),
	Categoria VARCHAR(255)
);

SELECT DISTINCT s.Nome
FROM stadio s
EXCEPT
SELECT DISTINCT i.NomeStadio
FROM incontro i
JOIN nazionale n1 ON n1.Paese = i.Squadra1
JOIN nazionale n2 ON n2.Paese = i.Squadra2
WHERE n1.Continente = 'Europa' OR n2.Continente = 'Europa';

SELECT SUM(s.Capienza) AS Capienza_Complessiva
FROM stadio s
JOIN incontro i ON s.Nome = i.NomeStadio
JOIN nazionale n ON n.Paese = i.Squadra1
WHERE n.Continente = 'Africa';

